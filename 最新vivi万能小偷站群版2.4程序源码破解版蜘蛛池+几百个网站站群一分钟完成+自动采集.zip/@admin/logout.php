<?php
/*--------------------------
����С͵վȺ
qq��910784119
---------------------------*/
setcookie("x_Cookie", "");
setcookie("y_Cookie", "");
echo "<script>location.href='index.php';</script>";
exit;
?>