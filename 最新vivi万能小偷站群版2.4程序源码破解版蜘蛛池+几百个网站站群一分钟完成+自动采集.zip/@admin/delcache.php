<?php
/*--------------------------
����С͵վȺ
qq��910784119
---------------------------*/
require_once('data.php');
require_once('checkAdmin.php');
$v_config=require_once('../data/config.php');
require_once('../inc/common.inc.php');
$collectid=isset($_GET ['collectid'])?$_GET ['collectid']:'';
$ac=isset($_GET ['ac'])?$_GET ['ac']:'';
$collectid = intval($collectid);
$collect_config_file=VV_DATA . "/config/{$collectid}.php";
if($collectid && is_file($collect_config_file)){
	$caiji_config = require($collect_config_file);
	$parse_url = parse_url($caiji_config['from_url']);
	$cachepath=$parse_url['host'];
}else{
	$cachepath='';
}
if ($ac=='') {
	echo ADMIN_HEAD;
?>
<body>
<div class="right">
 <?php include "welcome.php";?>
  <div class="right_main">
<table width="98%" cellspacing="1" cellpadding="4" border="0" class="tableoutline">
	<tbody>
		<tr class="tb_head">
			<td><h2><?php echo $collectid?'�ڵ�':'ȫ��';?>���������</h2></td>
		</tr>
	</tbody>
</table>
<table width="98%" border="0" cellpadding="4" cellspacing="1" class="tableoutline">
	<tbody id="config2">
		<tr align=center class="firstalt">
          <td width="30%">����˵��</td>
          <td width="30%">����Ŀ¼</td>
		  <td width="20%">�����С</td>
          <td width="20%">����</td>
        </tr>
		<tr align=center class="firstalt">
          <td>��ҳ����</td>
          <td>../data/cache/index/<?php echo $cachepath;?></td>
		  <td style="color: #FF0000;" id="getindexsize"><a href="javascript:" onclick='getdirsize("index");'>�����ȡ</a></td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?ac=del&del=index&collectid=<?php echo $collectid;?>';" name="Input"></td>
        </tr>
        <tr align=center class="firstalt">
          <td>����ҳ����</td>
          <td >../data/cache/html/<?php echo $cachepath;?></td>
		  <td style="color: #FF0000;" id="gethtmlsize"><a href="javascript:" onclick='getdirsize("html");'>�����ȡ</a></td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?ac=del&del=other&collectid=<?php echo $collectid;?>';" name="Input"></td>
        </tr>
		<tr align=center class="firstalt">
          <td>css����</td>
          <td >../data/cache/css/<?php echo $cachepath;?></td>
		  <td style="color: #FF0000;" id="getcsssize"><a href="javascript:" onclick='getdirsize("css");'>�����ȡ</a></td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?ac=del&del=css&collectid=<?php echo $collectid;?>';" name="Input"></td>
        </tr>
		<tr align=center class="firstalt">
          <td>js����</td>
          <td >../data/cache/js/<?php echo $cachepath;?></td>
		  <td style="color: #FF0000;" id="getjssize"><a href="javascript:" onclick='getdirsize("js");'>�����ȡ</a></td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?ac=del&del=js&collectid=<?php echo $collectid;?>';" name="Input"></td>
        </tr>
	<?php if(!$collectid){?>
		<tr align=center class="firstalt">
          <td>ͼƬ����</td>
          <td >../data/cache/img</td>
		  <td style="color: #FF0000;" id="getimgsize"><a href="javascript:" onclick='getdirsize("img");'>�����ȡ</a></td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?ac=del&del=img';" name="Input"></td>
        </tr>
		<tr align=center class="firstalt">
          <td>URL�ض��򻺴�</td>
          <td >../data/cache/redirect_url</td>
		  <td style="color: #FF0000;" id="getredirectsize"><a href="javascript:" onclick='getdirsize("redirect");'>�����ȡ</a></td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?ac=del&del=redirect';" name="Input"></td>
        </tr>
		<tr align=center class="firstalt">
          <td>֩�����м�¼</td>
          <td >../data/zhizhu.txt</td>
		  <td style="color: #FF0000;"><?php echo @round(@filesize(VV_DATA."/zhizhu.txt")/1024,2)?> KB</td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?ac=del&del=zhizhu';" name="Input"></td>
        </tr>
		<tr align=center class="firstalt">
          <td >һ�����ȫ������</td>
          <td >&nbsp;</td>
		  <td>&nbsp;</td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?ac=del&del=all';" name="Input"></td>
        </tr>
	<?php } ?>
	<?php if($collectid){?>
		<tr class="firstalt">
			<td align="center" colspan="10">
			<input type="button" onclick="javascript:location.href='caiji_config.php';" value=" ���ؽڵ� " name="Input" class="bginput"></td>
		</tr>
	<?php } ?>
	</tbody>
</table>
</div>
</div>
<script type="text/javascript">
function getdirsize(id){
	var elem='#get'+id+'size';
	$(elem).html('<img src="../public/img/load.gif"> ������...');
	$.get("?ac=get"+id+"size&collectid=<?php echo $collectid;?>&_t="+Math.random()*10,function(data){
	  $(elem).html(data);
	});
}
</script>
<?php include "footer.php";?>
</body>
</html>
<?php
}elseif($ac == 'getindexsize') {
	$dir=$collectid?'/'.$cachepath:'';
	echo @getRealSize(@getDirSize(VV_CACHE.'/index'.$dir)).' MB';
}elseif($ac == 'gethtmlsize') {
	$dir=$collectid?'/'.$cachepath:'';
	$dir=VV_CACHE.'/html'.$dir;
	echo @getRealSize(@getDirSize($dir)).' MB';
}elseif($ac == 'getjssize') {
	$dir=$collectid?'/'.$cachepath:'';
	echo @getRealSize(@getDirSize(VV_CACHE.'/js'.$dir)).' MB';
}elseif($ac == 'getredirectsize') {
	echo @getRealSize(@getDirSize(VV_CACHE.'/redirect_url')).' MB';
}elseif($ac == 'getcsssize') {
	$dir=$collectid?'/'.$cachepath:'';
	echo @getRealSize(@getDirSize(VV_CACHE.'/css'.$dir)).' MB';
}elseif($ac == 'getimgsize') {
	echo @getRealSize(@getDirSize(VV_CACHE.'/img')).' MB';
}elseif($ac == 'del') {
	$dir=$collectid?'/'.$cachepath:'';
	if($_GET['del']=='zhizhu'){
		@unlink(VV_DATA."/zhizhu.txt");
	}elseif($_GET['del']=='index'){
		@removedir(VV_CACHE."/index".$dir);
	}elseif($_GET['del']=='other'){
		@removedir(VV_CACHE.'/html'.$dir);
	}elseif($_GET['del']=='css'){
		@removedir(VV_CACHE.'/css'.$dir);
	}elseif($_GET['del']=='js'){
		@removedir(VV_CACHE.'/js'.$dir);
	}elseif($_GET['del']=='img'){
		@removedir(VV_CACHE.'/img');
	}elseif($_GET['del']=='redirect'){
		@removedir(VV_CACHE.'/redirect_url');
	}elseif($_GET['del']=='all'){
		@removedir(VV_CACHE);
		@unlink(VV_DATA."/zhizhu.txt");
	}
	$referer=$collectid?('delcache.php?collectid='.$collectid):'delcache.php';
	ShowMsg("��ϲ��,��������ɹ���",$referer,2000);
}
?>