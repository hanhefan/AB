function addFlash(url,w,h){
	  document.write('<embed src="http://www.tudou.com/v/'+url+'/&withRecommendList=false&autoPlay=true&videoClickNavigate=false&withSearchBar=false&withRecommendList=false/v.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allownetworking="internal" allowfullscreen="true" wmode="transparent" width="'+w+'" height="'+h+'"></embed>');
}

