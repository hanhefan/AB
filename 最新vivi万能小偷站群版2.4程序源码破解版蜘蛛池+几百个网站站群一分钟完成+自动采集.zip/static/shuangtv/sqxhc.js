document.writeln("<script language=\"javascript\">");
document.writeln("setTimeout(\"showswf();\",100);");
document.writeln("function showswf(){");
document.writeln("document.getElementById(\"bfq\").style.display=\"block\";");
document.writeln("document.getElementById(\"bfhc\").style.display=\"none\";");
document.writeln("}");
document.writeln("  <\/script>");