<?php
return array (
  'http://127.0.0.1/4/' => 2,
  'http://www.t.com/' => 2,
);
?>