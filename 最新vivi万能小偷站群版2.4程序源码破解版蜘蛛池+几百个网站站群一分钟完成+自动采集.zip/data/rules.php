<?php
//QQ995676868
error_reporting(0);
if (!defined('VV_INC')) {
    die(header('HTTP/1.1 403 Forbidden'));
}
banip();
$v_config = (require VV_DATA . '/config.php');
$GLOBALS['debug'] = array();
$domains_config_file = VV_DATA . '/domain_config.php';
if (!is_file($domains_config_file)) {
    ShowMsg('վ�������ļ������ڣ�����~', 'javascript:', 3000);
}
$ac = isset($_GET['ac']) ? $_GET['ac'] : '';
if ($ac == 'yulan') {
    $collectid = @$_GET['collectid'];
} else {
    $domains_config = (require_once $domains_config_file);
    foreach ($domains_config as $k => $vo) {
        if ($k == $_SERVER['HTTP_HOST'] || preg_match('~' . $_SERVER['HTTP_HOST'] . ',~', $k) || preg_match('~,' . $_SERVER['HTTP_HOST'] . '~', $k)) {
            $collectid = $vo;
        }
    }
    if (!$collectid) {
        $collectid = $v_config['collectid'];
    }
}
$collectid = intval($collectid);
$collect_config_file = VV_DATA . "/config/{$collectid}.php";
if (is_file($collect_config_file)) {
    $caiji_config = (require $collect_config_file);
} else {
    ShowMsg('�ڵ������ļ������ڣ�����~', 'javascript:', 3000);
}
if ($caiji_config['web_close'] == 'on') {
    die($caiji_config['web_closecon']);
}
if ($caiji_config['web_debug'] == 'on') {
    @ini_set('display_errors', 'On');
}
if ($caiji_config['cache_set']) {
    $cache_type = array('indexcache', 'othercache', 'csscache', 'cacheon', 'csscachetime', 'jscachetime', 'delcache', 'delcachetime', 'deloldcache', 'robotlogon', 'jscache', 'imgcache');
    foreach ($cache_type as $k => $vo) {
        $v_config[$vo] = $caiji_config[$vo];
    }
}
if ($ac == 'yulan') {
    $v_config['cacheon'] = false;
}
$web_type = array('web_name', 'web_seo_name', 'web_keywords', 'web_description', 'web_tongji', 'web_404_url');
foreach ($web_type as $k => $vo) {
    $v_config[$vo] = $caiji_config[$vo];
}
//$v_config['web_url'] = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/';
$v_config['web_url']='/';
if ($v_config['web_urlencode'] && $_SERVER['QUERY_STRING']) {
    $_SERVER['QUERY_STRING'] = preg_replace('~\\.(jpg|css|js|' . $v_config['web_urlencode_suffix'] . ')$~i', '', $_SERVER['QUERY_STRING']);
    $_SERVER['QUERY_STRING'] = decode_id($_SERVER['QUERY_STRING']);
}
list($_SERVER['QUERY_STRING'], ) = explode('#', $_SERVER['QUERY_STRING']);
$_SERVER['QUERY_STRING'] = convert_query($_SERVER['QUERY_STRING'], $caiji_config['charset']);
$charset = SCRIPT == 'search' && $caiji_config['search_charset'] ? $caiji_config['search_charset'] : $caiji_config['charset'];
$temp = array();
if (!empty($_POST)) {
    foreach ($_POST as $k => $vo) {
        $k = convert_query($k, $charset);
        $temp[$k] = convert_query($vo, $charset);
    }
}
$_POST = $temp;
$temp = array();
foreach ($_GET as $k => $vo) {
    $k = convert_query($k, $charset);
    $temp[$k] = convert_query($vo, $charset);
}
$_GET = $temp;
if ($ac == 'yulan') {
    if (isset($_GET['url'])) {
        $caiji_config['from_url'] = $_GET['url'];
    }
}
$caiji_config['resdomain'] = $caiji_config['resdomain'] ? $caiji_config['resdomain'] : $caiji_config['other_imgurl'];
$from_url = $caiji_config['from_url'];
$isouturl = false;
if (isset($geturl)) {
    $from_url = $geturl;
    $isouturl = true;
}
define('ISOUTURL', $isouturl);
$parse_url = parse_url($from_url);
$port = isset($parse_url['port']) ? $parse_url['port'] : '';
$server_url = $parse_url['scheme'] . '://' . $parse_url['host'];
$server_host = $parse_url['host'];
if ($port) {
    $server_url = $server_url . ':' . $port;
}
include VV_INC . '/delcache.php';
$str = '';
$sign = $v_config['web_remark'] ? '/' . $v_config['web_remark'] . '/' : '/';
$temp_url = parse_url($v_config['web_url']);
define('WEB_ROOT', substr($temp_url['path'], 0, -1));
if (!$caiji_config['rewrite'] || !OoO0o0O0o()) {
    $sign = '?';
    if (SCRIPT == 'search') {
        $sign = WEB_ROOT . '/?';
    }
}
if (empty($_SERVER['QUERY_STRING'])) {
    $geturl = $from_url;
    $cacheid = md5($geturl);
    $cachefile = VV_CACHE . '/index/' . $server_host . '/' . getHashDir($cacheid, 2) . '/' . substr(md5($cacheid), 0, 16) . '.cache';
    $cachetime = $v_config['indexcache'];
} else {
    if (substr($_SERVER['QUERY_STRING'], 0, 1) == '/') {
        $_SERVER['QUERY_STRING'] = substr($_SERVER['QUERY_STRING'], 1);
    }
    if (!isset($geturl)) {
        $geturl = $server_url . '/' . $_SERVER['QUERY_STRING'];
    }
    $cacheid = md5($geturl);
    $cachefile = getcachefile($cacheid, $server_host);
    $cachetime = $v_config['othercache'];
}
if (SCRIPT == 'search') {
    if (!empty($_POST)) {
        $searchurl = $caiji_config['search_url'];
    } else {
        unset($_GET['action']);
        $getstr = http_build_query($_GET);
        $search_sign = stripos($caiji_config['search_url'], '?') > -1 ? '&' : '?';
        $searchurl = $caiji_config['search_url'] . $search_sign . $getstr;
    }
    if (substr($searchurl, 0, 7) != 'http://' && substr($searchurl, 0, 8) != 'https://') {
        $searchurl = $server_url . '/' . ltrim($searchurl, '/');
    }
    $cacheid = !empty($_POST) ? md5($searchurl . http_build_query($_POST)) : md5($searchurl);
    $cachefile = getcachefile($cacheid, $server_host);
    $cachetime = $v_config['othercache'];
}
$extarr = array('php', 'html', 'shtml', 'htm', 'jsp', 'xhtml', 'asp', 'aspx', 'txt', 'action', 'xml', 'css', 'js', 'gif', 'jpg', 'jpeg', 'png', 'bmp', 'ico', 'swf');
foreach ($extarr as $vo) {
    $geturl = str_replace('.' . $vo . '&', '.' . $vo . '?', $geturl);
}
if (SCRIPT != 'search' && $_SERVER['QUERY_STRING'] && $caiji_config['rewrite'] && (substr($_SERVER['REQUEST_URI'], 0, 2) == '/?' || !$v_config['web_remark'] && substr($_SERVER['REQUEST_URI'], 0, 11) == '/index.php?' || preg_match('~^/' . $v_config['web_remark'] . '/\\?~', $_SERVER['REQUEST_URI']) || preg_match('~^/' . $v_config['web_remark'] . '/index.php\\?~', $_SERVER['REQUEST_URI']))) {
    $geturl = $server_url . '/?' . $_SERVER['QUERY_STRING'];
}
if (stripos($geturl, '?') === false && stripos($geturl, '&') > -1) {
    $geturl = preg_replace('~\\&~', '?', $geturl, 1);
}
if ($ac == 'yulan') {
    $geturl = $from_url;
}
if (SCRIPT == 'search') {
    $parse_url = parse_url($searchurl);
} else {
    $parse_url = parse_url($geturl);
}
$urlpath = $parse_url['path'];
$urlpathext = pathinfo($parse_url['path'], PATHINFO_EXTENSION);
if (empty($urlpathext)) {
    if (substr($urlpath, -1) != '/') {
        $urlpath .= '/';
    }
} else {
    $urlpathinfo = pathinfo($parse_url['path']);
    $urldirname = $urlpathinfo['dirname'];
    $urlbasename = $urlpathinfo['basename'];
    $urlpath = str_replace($urlbasename, '', $parse_url['path']);
    if ($urldirname != '\\') {
        $urlpath = $urldirname . '/';
    }
}
if (substr($urlpath, 0, 1) == '/') {
    $urlpath = substr($urlpath, 1);
}
$urlext = pathinfo($parse_url['path'], PATHINFO_EXTENSION);
$imgarr = array('gif', 'jpg', 'jpeg', 'png', 'bmp', 'ico');
if (strpos($_SERVER['QUERY_STRING'], '..') === false && @is_file(VV_ROOT . '/' . $_SERVER['QUERY_STRING'])) {
    $getfile = false;
    if (in_array($urlext, $imgarr)) {
        header("Content-type: image/{$urlext}; charset=gbk");
        $getfile = true;
    }
    if ($urlext == 'js') {
        header('Content-type: text/javascript; charset=gbk');
        $getfile = true;
    }
    if ($urlext == 'css') {
        header('Content-type: text/css; charset=gbk');
        $getfile = true;
    }
    if ($getfile) {
        echo @file_get_contents(VV_ROOT . '/' . $_SERVER['QUERY_STRING']);
        die;
    }
}
if (in_array($urlext, $imgarr)) {
    if ($v_config['imgcache'] && OoO0o0O0o()) {
        $cachetime = $v_config['imgcachetime'];
        $extarr = array_merge($extarr, $imgarr);
        header("Content-type: image/{$urlext}; charset=gbk");
        $cachefile = VV_CACHE . '/img/' . getHashDir($cacheid, 2) . '/' . substr(md5($cacheid), 0, 16) . '.jpg';
        if ($cachetime && (!is_file($cachefile) || @filemtime($cachefile) + $cachetime * 3600 <= time())) {
            $str = $caiji->geturl($geturl);
            if (!empty($str)) {
                write($cachefile, $str);
            } else {
                $str = file_get_contents($cachefile);
                write($cachefile, $str);
            }
        } else {
            $str = file_get_contents($cachefile);
        }
        die($str);
    } else {
        header('Content-Type: image/jpeg; charset=UTF-8');
        header("Location: {$geturl}");
        die;
    }
}
if ($urlext == 'css') {
    header('Content-type: text/css;');
    $cachetime = $v_config['csscachetime'];
    $cachefile = getcsscachefile($cacheid, $server_host);
}
if ($urlext == 'js') {
    header('Content-type: text/javascript; charset=gbk');
    $cachetime = $v_config['jscachetime'];
    $cachefile = getjscachefile($cacheid, $server_host);
}
if ($urlext != '' && !in_array($urlext, $extarr)) {
    header('HTTP/1.1 301 Moved Permanently');
    header("Location:{$geturl}");
    die;
}
include VV_DATA . '/rules_get.php';
if ($ac == 'yulan') {
    $str = _htmlspecialchars($str);
    $str = "\t<script type=\"text/javascript\" src=\"../public/js/syntaxhighlighter/scripts/shCore.js\"></script>\r\n\t<script type=\"text/javascript\" src=\"../public/js/syntaxhighlighter/scripts/shBrushXml.js\"></script>\r\n\t<link type=\"text/css\" rel=\"stylesheet\" href=\"../public/js/syntaxhighlighter/styles/shCore.css\"/>\r\n\t<link type=\"text/css\" rel=\"stylesheet\" href=\"../public/js/syntaxhighlighter/styles/shThemeEditplus.css\"/>\r\n\t<script type=\"text/javascript\">\r\n\t\tSyntaxHighlighter.config.clipboardSwf = '../public/js/syntaxhighlighter/scripts/clipboard.swf';\r\n\t\tSyntaxHighlighter.config.tagName = 'textarea';\r\n\t\tSyntaxHighlighter.all();\r\n\t</script>\r\n\t<table width=\"99%\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\" class=\"tableoutline\">\r\n\t<tbody>\r\n\t\t<tr nowrap class=\"tb_head\">\r\n\t\t\t<td><h2>Դ����鿴</h2></td>\r\n\t\t</tr>\r\n\t</tbody>\r\n\t<tr nowrap class=\"firstalt\">\r\n\t\t<td><b>����Ϊ�ɼ����� [{$caiji_config['name']}] ��Դ���룬����Ը��������д���˹���:</b></td>\r\n\t</tr>\r\n\t<tr nowrap class=\"firstalt\">\r\n\t\t<form method=\"get\" action=\"caiji_config.php\">\r\n\t\t<input type=\"hidden\" name=\"ac\" value=\"{$ac}\" />\r\n\t\t<input type=\"hidden\" name=\"collectid\" value=\"{$collectid}\" />\r\n\t\t<td><input type=\"text\" name=\"url\" size=\"80\" value=\"{$from_url}\" onFocus=\"this.style.borderColor='#00CC00'\" onBlur=\"this.style.borderColor='#999999'\" > <input type=\"submit\" value=\"�鿴Դ����\" /></td>\r\n\t\t</form>\r\n\t</tr>\r\n\t<tr nowrap class=\"firstalt\">\r\n\t\t<td><textarea style=\"height:500px\" class=\"brush: html;auto-links:false;\">{$str}</textarea></td>\r\n\t</tr>\r\n</table>\r\n</body>\r\n</html>";
    $str = ADMIN_HEAD . $str;
    die($str);
}
if ($urlext == 'css' || $urlext == 'js') {
    echo $str;
} else {
    if (in_array($urlext, $extarr) || stripos($str, '<head>') > -1 || stripos($str, '<html>') > -1 || stripos($str, '<body>') > -1) {
        $GLOBALS['debug'][] = '���������ܹ���ʱ��' . round(debug_time() - RUN_TIME, 4) . 's';
        if ($caiji_config['web_debug'] == 'on') {
            echo echo_debug($GLOBALS['debug']);
        }
        $tplfile = VV_TMPL . '/index.html';
        if ($caiji_config['tplfile']) {
            $caiji_config['tplfile'] = str_replace('..', '', $caiji_config['tplfile']);
            $caiji_tplfile = VV_TMPL . '/' . $caiji_config['tplfile'];
            if (is_file($caiji_tplfile)) {
                $tplfile = $caiji_tplfile;
            }
        }
        $html = $str;
        if (substr($html, 0, 1) == '?') {
            $html = substr($html, 1);
        }
        include $tplfile;
    } else {
        echo $str;
    }
}